<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="styles.css">
    <style>

.container {
  width: 100%;
  max-width: 400px;
}

.card {
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h2 {
  text-align: center;
  color: #333;
}

form {
  display: flex;
  flex-direction: column;
}

input {
  padding: 10px;
  margin-bottom: 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  transition: border-color 0.3s ease-in-out;
  outline: none;
  color: #333;
}

input:focus {
  border-color: #555;
}

button {
  background-color: #3498db;
  color: #fff;
  padding: 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease-in-out;
}

button:hover {
  background-color: #2980b9;
}

    </style>

	<title>adminpage</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<span class="text">e-Kaunseling</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="landingpage.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Utama</span>
				</a>
			</li>
			<li>
				<a href="rekodtempahan.php">
					<i class='bx bxs-shopping-bag-alt' ></i>
					<span class="text">Rekod tempahan</span>
				</a>
			</li>
			<li>
				<a href="aktiviti.php">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Aktiviti</span>
				</a>
			</li>
			<li>
				<a href="giliran.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Giliran</span>
				</a>
			</li>
			<li>
				<a href="pelajar.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Pelajar</span>
				</a>
			</li>
            <li>
				<a href="login.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Login</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Login</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Login</a>
						</li>
					</ul>
				</div>
			</div>  


			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Login admin</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<div class="container2">
  <div class="card2">
    <h2>Login</h2>
    <form>
      <input type="text" id="username" name="username" placeholder="Username" required>
      <input type="password" id="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
  </div>
</div>
				</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>