<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="styles.css">

	<title>adminpage</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<span class="text">e-Kaunseling</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="landingpage.php">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Utama</span>
				</a>
			</li>
			<li>
				<a href="rekodtempahan.php">
					<i class='bx bxs-shopping-bag-alt' ></i>
					<span class="text">Rekod tempahan</span>
				</a>
			</li>
			<li>
				<a href="aktiviti.php">
					<i class='bx bxs-doughnut-chart' ></i>
					<span class="text">Aktiviti</span>
				</a>
			</li>
			<li>
				<a href="giliran.php">
					<i class='bx bxs-message-dots' ></i>
					<span class="text">Giliran</span>
				</a>
			</li>
			<li>
				<a href="pelajar.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Pelajar</span>
				</a>
			</li>
			<li>
				<a href="login.php">
					<i class='bx bxs-group' ></i>
					<span class="text">Login</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Tambah admin</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Tambah admin</a>
						</li>
					</ul>
				</div>
			</div>  


			<div class="table-data">
				<div class="order">
					<div class="head">
						<h3>Recent Orders</h3>
						<i class='bx bx-search' ></i>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
								<th>User</th>
								<th>Date Order</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status completed">Completed</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status pending">Pending</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status process">Process</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status pending">Pending</span></td>
							</tr>
							<tr>
								<td>
									<img src="img/people.png">
									<p>John Doe</p>
								</td>
								<td>01-10-2021</td>
								<td><span class="status completed">Completed</span></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>